export class Configuration {
    public apiUrl = 'http://quickread.com/api/auth';
}
